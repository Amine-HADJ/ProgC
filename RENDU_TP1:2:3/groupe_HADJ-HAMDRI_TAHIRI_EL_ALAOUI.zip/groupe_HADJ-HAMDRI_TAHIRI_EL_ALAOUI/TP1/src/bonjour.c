/* Fichier: bonjour.c
* affiche: 'Bonjour le Monde!'
* auteur: HADJ-HAMDRI MOHAMMED-AMINE / TAHIRI EL ALAOUI YOUNESS
*/


#include <stdio.h>   // headers (pour avoir acces à printf)

int main() {   

   printf("Bonjour le Monde!");  // affiche le message
   
   return 0;  // fin du programme
}