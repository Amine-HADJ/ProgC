Dans l'ensemble ces trois premiers Tps nous ont beaucoup plus car les exercices était variés et nous ont permis de manipuler toutes sortes de variables. Nous avons aussi découvert et appris les structures ansi que les pointeurs.

Nous évaluons la difficulté de ces Tps à 2/5 car nous avons eu quelques difficultés à comprendre les structures et les pointeurs mais nous avons réussi à les surmonter.

