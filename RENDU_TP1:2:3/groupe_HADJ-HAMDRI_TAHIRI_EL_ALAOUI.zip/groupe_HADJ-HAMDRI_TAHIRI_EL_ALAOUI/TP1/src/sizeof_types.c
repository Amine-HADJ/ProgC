/* Fichier: sizeof_types.c
 * affiche : la taille en octets des différents types de base (signed and unsigned)
 * auteur: HADJ-HAMDRI MOHAMMED-AMINE / TAHIRI EL ALAOUI YOUNESS
 */

#include <stdio.h> // headers

int main()
{

    printf("Taille en octets des types de données :\n");

    // sizeof() retourne la taille en octets du type de donnée passé en paramètre

    printf("char: %lu octets\n", sizeof(char));

    printf("short: %lu octets\n", sizeof(short));

    printf("int: %lu octets\n", sizeof(int));

    printf("long int: %lu octets\n", sizeof(long int));

    printf("long long int: %lu octets\n", sizeof(long long int));

    printf("float: %lu octets\n", sizeof(float));

    printf("double: %lu octets\n", sizeof(double));

    printf("long double: %lu octets\n", sizeof(long double));

    return 0; // fin du programme
}
