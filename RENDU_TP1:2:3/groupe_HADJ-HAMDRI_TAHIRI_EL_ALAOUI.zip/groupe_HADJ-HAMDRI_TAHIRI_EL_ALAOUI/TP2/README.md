# Bibliothèques
* <stdio.h> 
* <stdlib.h>
* <string.h>
* <time.h> 

# Références
* https://www.tutorialspoint.com
* https://www.programiz.com
* https://www.geeksforgeeks.org
* https://www.youtube.com

# Difficulté
* moyenne (2h30)

# Commentaires
* Première vraie approche des pointeurs et des structures 
* Petite difficulté à comprendre le fonctionnement des pointeurs 

