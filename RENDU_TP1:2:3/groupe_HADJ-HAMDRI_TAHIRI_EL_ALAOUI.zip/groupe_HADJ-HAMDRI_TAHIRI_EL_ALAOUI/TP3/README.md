# Bibliothèques
* <stdio.h>
* <stdlib.h>
* <time.h>

# Références
* https://www.openclassrooms.com
* https://www.tutorialspoint.com
* https://www.geeksforgeeks.org
* https://www.youtube.com

# Difficulté
* 3/5
* environ 3h30

# Commentaires
* Ce TP est un peu plus difficile que les précédents, mais il est très intéressant car il permet de manipuler des structures de données complexes.
* Les différentes façcon de trier utilisées sont très intéressantes et permettent de comprendre le fonctionnement de ces algorithmes.
* Le tri par insertion est le plus simple à comprendre et à mettre en oeuvre.

