# Bibliothèques
* <stdio.h>
* <math.h>
* <stdbool.h>

# Références
* https://www.w3schools.com
* https://www.freecodecamp.org
* https://www.javatpoint.com
* https://www.youtube.com


# Difficulté
* facile (1h30)

# Commentaires
* Ayant déja quelques petites bases en C, ce TP a été plutot facile mis à part les 2 derniers exos qui ont demandé un peu plus de temps de conception.
* Ce TP nous a plus car il m'a permis de revoir les bases du C et de me remettre dans le bain.


